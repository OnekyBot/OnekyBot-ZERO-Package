var searchData=
[
  ['tickerstate_0',['TickerState',['../struct_ticker_state.html',1,'']]]
];
